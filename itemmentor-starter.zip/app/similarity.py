import os, json, subprocess, psycopg2
from dotenv import load_dotenv

load_dotenv()
DB_URL = os.getenv("DATABASE_URL", "postgresql://user:password@localhost:5432/itemmentor")
EMBED_MODEL = os.getenv("EMBED_MODEL", "nomic-embed-text")

def embed(text: str):
    res = subprocess.run(["ollama", "embed", "-m", EMBED_MODEL, text], capture_output=True, text=True, check=True)
    return json.loads(res.stdout)["embedding"]

def top_k_similar(query_text: str, k: int = 5):
    qvec = embed(query_text)
    conn = psycopg2.connect(DB_URL)
    with conn.cursor() as cur:
        cur.execute(
            """
            SELECT i.item_id, i.stem, i.difficulty, i.discrimination, COALESCE(d.name,'') AS domain,
                   EXISTS (SELECT 1 FROM enemy_pairs e WHERE e.item_id = i.item_id) AS has_enemy,
                   1 - (ie.embedding <=> %s) AS similarity
            FROM item_embeddings ie
            JOIN items i ON i.item_id = ie.item_id
            LEFT JOIN domains d ON d.domain_id = i.domain_id
            ORDER BY ie.embedding <=> %s
            LIMIT %s
            """,
            (qvec, qvec, k)
        )
        rows = cur.fetchall()
    conn.close()
    return [
        {"item_id": r[0], "stem": r[1], "difficulty": r[2], "discrimination": r[3], "domain": r[4], "has_enemy": bool(r[5]), "similarity": float(r[6])}
        for r in rows
    ]

if __name__ == "__main__":
    print(top_k_similar("A patient presents with..."))
